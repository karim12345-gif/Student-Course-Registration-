package com.karim.Controller;

import com.karim.Entity.Student;
import com.karim.Service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


import java.util.Collection;
//is used to create RESTful web services using Spring MVC.
// Spring RestController takes care of mapping request data to the defined request handler method.
// Once response body is generated from the handler method, it converts it to JSON or XML response.
@RestController
@RequestMapping("/students")
//controller offloads the requests through student service
public class StudentController {

    @Autowired// is used for automatic dependency injection,
    private StudentService studentService;

    @RequestMapping(method = RequestMethod.GET)
    public Collection<Student> getAllStudents(){
        return studentService.getAllStudents();
    };

//get the id from StudentDao class and from the Student class that has the data privat and encapsulated thats why we use get
    @RequestMapping( value ="/{id}", method = RequestMethod.GET)
        public Student getStudentById(@PathVariable("id") int id){
            return studentService.getStudentById(id);
        }

        // Deleting ID from the database
    @RequestMapping( value ="/{id}", method = RequestMethod.DELETE)
    public void deleteStudentById(@PathVariable("id") int id){
        studentService.removeStudentById(id);
    }

    //put data for students in the data base
    // we have  to accept JSON
    @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
    // to read the body we need to add request body
    public void updateStudentById(@RequestBody Student student){
        this.studentService.updateStudent(student);
    }


    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    // to read the body we need to add request body
    public void insert(@RequestBody Student student){
        this.studentService.insertStudent(student);
    }




    }

