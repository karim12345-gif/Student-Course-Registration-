package com.karim.Dao;

import com.karim.Entity.Student;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
//@ Component  is annotation marks a java class as bean so the component scanning mechanism can pick it up
// and pull it into the application context  --> too general
@Repository // enable annotated classes to be discovered and registered with applications context
@Qualifier("Fake Data")
public class FakeStudentsDaoImpl implements StudentsDao {

    private Student student;
    // our data that was put manually


    private static  Map<Integer, Student> students; // we can add final, but we dont want it becuase im going to create
    // a database

    static {
// in hashmap integer is the keys and then Student is the values
        students = new HashMap<Integer,Student>(){
            // so now we used postman and we deleted the 2nd studnet from the database

            {
                // adding manually data for now
                put(1,new Student(1,"karim","computer Science"));
                put(2,new Student(2,"Anna","Maths"));
                put(3,new Student(3,"Mariam","Pharmacy"));

            }
        };
    }


    // get Students information
    // this is going to return the students name,id,course
    //goes to the student class with the data
    @Override
    public Collection<Student> getAllStudents(){

        return this.students.values();
    };


    // will get the student ID from the Student encapsualtion class
    @Override
    public Student getStudentById(int id){
        return this.students.get(id);
    }


    @Override
    public void removeStudentById(int id) {
        this.students.remove(id);
    }


    // setting the name id and course and getting them
    @Override
    public void updateStudentById(Student student){
        Student s = students.get(student.getId());
        s.setCourse(student.getCourse());
        s.setName(student.getName());
        //This method is used to associate the specified value with the specified key in this map.
        // put(k key, v value)
        // get id will get the student
        students.put(student.getId(), student);



    }

    @Override
    public void inserStudentToDB(Student student) {
        this.students.put(student.getId(),student);
    }
}
