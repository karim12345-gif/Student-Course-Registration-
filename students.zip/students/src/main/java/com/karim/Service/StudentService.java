package com.karim.Service;

import com.karim.Dao.FakeStudentsDaoImpl;
import com.karim.Entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service //annotation is used with classes that provide some business functionalities
//spring context will autodetect these classes when annotation-based configuration and classpath scanning is used.
public class StudentService {
    @Autowired // will find the bean of type StudentsDao, adn then instantiate and then inject  it here in line 14
    @Qualifier("Fake Data")
    private FakeStudentsDaoImpl fakeStudentsDaoImpl;

    // get Students information
    // this is going to return the students name,id,course
    //goes to the student class with the data
    // this ggoes back to the studentsDao
    public Collection<Student> getAllStudents(){
        return this.fakeStudentsDaoImpl.getAllStudents();
    };


    // getting the id from the Students Data base or StudentsDao class that gets it from Student class it self
    public Student getStudentById(int id){
        return this.fakeStudentsDaoImpl.getStudentById(id);

    }

    public void removeStudentById(int id) {
        this.fakeStudentsDaoImpl.removeStudentById(id);
    }



    public void updateStudent(Student student){
        this.fakeStudentsDaoImpl.updateStudentById(student);
    }

    public void insertStudent(Student student) {
        this.fakeStudentsDaoImpl.inserStudentToDB(student);
    }
}
